package com.example.demo.db;

public class DB {
}
