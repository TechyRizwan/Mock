package com.example.demo.controller;

import com.example.demo.service.ServiceRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
    @Autowired
    ServiceRequest Service;

    @GetMapping("/login")

    public void login(){
        System.out.println("Request for validation from Controller");
        service.validateRequest();
        System.out.println("Controller allows login");

    }
}